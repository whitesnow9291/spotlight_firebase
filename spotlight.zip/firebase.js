
(function(){
var config = {
  apiKey: "AIzaSyDBa71mRbterPI-0a-2vA1nOFxauD-2Iac",
  authDomain: "spotlight-f42d3.firebaseapp.com",
  databaseURL: "https://spotlight-f42d3.firebaseio.com",
  storageBucket: "spotlight-f42d3.appspot.com",
  messagingSenderId: "658861158175"
};
firebase.initializeApp(config);
}());
